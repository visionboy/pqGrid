require("./pqgrid.min.css");
require("./pqgrid.ui.min.css");

module.exports = require('./pqgrid.min.js');