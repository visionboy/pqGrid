/*!
 * ParamQuery Select v1.3.19
 * 
 * Copyright (c) 2015-2019 Paramvir Dhindsa (http://paramquery.com)
 * Released under Commercial license
 * http://paramquery.com/pro/license
 *
 */
require('jquery-ui-pack');

require("./pqselect.dev.css");

module.exports = require("./pqselect.dev.js");